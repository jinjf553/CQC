<?php get_header(); ?>
<div class="content-wrap">
	<div style="text-align:center;padding:10px 0;font-

size:16px;background-color:#ffffff;">
		<h2 style="font-size:36px;margin-bottom:10px;">哎哟～页面找

不到了～休息一下，玩个游戏吧！</h2>
  <embed type="application/x-shockwave-flash" width="600" height="400" 

src="http://images.yusi123.com/zhuamao.swf" wmode="transparent" 

quality="high" scale="noborder" flashvars="width=600&amp;height=400" 

allowscriptaccess="sameDomain" align="L">
<br>
	<p align="center">
		<font face="微软雅黑" size="5" color="#0099CC">
			<a target="_blank" href="http://cuiqingcai.com/">首

页</a>&nbsp;
			<a target="_blank" 

href="http://cuiqingcai.com/category/life" title="">生活笔记</a>&nbsp;
			<a target="_blank" 

href="http://cuiqingcai.com/art">艺术之风</a>&nbsp;
			<a target="_blank" 

href="http://cuiqingcai.com/category/resources">福利专区</a>&nbsp;
			<a target="_blank" 

href="http://cuiqingcai.com/contact">给我留言</a>&nbsp;
		</font>
	</p>
<p align="center">
	
</div>